<?php
    $conn = mysqli_connect("localhost", "root", "", "lia");
    if(!$conn){
        die("Sorry...! Failes to connect to database");
    }
?>